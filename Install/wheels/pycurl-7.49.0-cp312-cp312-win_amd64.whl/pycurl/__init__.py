"""""" # start delvewheel patch
def _delvewheel_patch_1_13_2():
    import os
    if os.path.isdir(libs_dir := os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, 'pycurl.libs'))):
        os.add_dll_directory(libs_dir)


_delvewheel_patch_1_13_2()
del _delvewheel_patch_1_13_2
# end delvewheel patch

from pycurl import _pycurl
from pycurl._pycurl import *  # noqa: F401, F403
from pycurl.async_multi import AsyncCurlMulti as AsyncCurlMulti

__all__ = [name for name in dir(_pycurl) if not name.startswith("_")]
__all__.append("AsyncCurlMulti")
